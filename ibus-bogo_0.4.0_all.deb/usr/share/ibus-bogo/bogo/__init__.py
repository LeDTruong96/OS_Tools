from .bogo import process_key, get_default_config
